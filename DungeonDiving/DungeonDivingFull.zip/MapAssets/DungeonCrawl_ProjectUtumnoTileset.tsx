<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.2" tiledversion="1.2.1" name="DungeonCrawl_ProjectUtumnoTileset" tilewidth="32" tileheight="32" tilecount="3072" columns="64">
 <image source="DungeonCrawl_ProjectUtumnoTileset.png" width="2048" height="1536"/>
</tileset>
