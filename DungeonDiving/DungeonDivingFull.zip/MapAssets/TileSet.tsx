<?xml version="1.0" encoding="UTF-8"?>
<tileset name="TileSet" tilewidth="32" tileheight="32" tilecount="192" columns="12">
 <image source="//sulfur/users/mcampbell/Documents/TileSet.png" width="384" height="512"/>
</tileset>
