

win_width = 800
win_height = 600
tile_w = 20
tile_h = 20
grid_on = False
move_delay = 0.1
white = (255, 255, 255)
red = (255, 0, 0)
green = (0, 255, 0)